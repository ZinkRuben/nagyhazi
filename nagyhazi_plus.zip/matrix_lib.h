//
// Created by Zear on 11/13/2022.
//

#ifndef NAGYHAZI_MATRIX_LIB_H
#define NAGYHAZI_MATRIX_LIB_H
#include "struct.h"
matrix m_cpy(matrix m);
void free_matrix(matrix m);



#endif //NAGYHAZI_MATRIX_LIB_H
