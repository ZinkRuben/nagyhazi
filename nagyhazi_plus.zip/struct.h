
#ifndef NAGYHAZI_STRUCT_H
#define NAGYHAZI_STRUCT_H
typedef struct matrix {
    int height, width;
    double **rows;
} matrix;
#endif
