//
// Created by Zear on 11/13/2022.
//


#ifndef NAGYHAZI_LINE_OPERATIONS_H
#define NAGYHAZI_LINE_OPERATIONS_H
#include "struct.h"

double *skalar_multip_line(double *line, int length, double scalar);
double *add_lines(double *line1, double *line2, int length);
#endif //NAGYHAZI_LINE_OPERATIONS_H
