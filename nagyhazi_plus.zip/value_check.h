//
// Created by Zear on 11/13/2022.
//

#ifndef NAGYHAZI_VALUE_CHECK_H
#define NAGYHAZI_VALUE_CHECK_H
#include "struct.h"

bool check_all_zero_line(double *line, int length);
bool check_invalid_line(double *line, int length);

#endif //NAGYHAZI_VALUE_CHECK_H
